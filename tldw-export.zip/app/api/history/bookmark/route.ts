import { NextRequest, NextResponse } from 'next/server'
import { getRedisClient } from '@/lib/redis'
import type { HistoryEntry } from '@/lib/history.types'

const HISTORY_TTL = 86400 * 30 // 30 days

// PATCH /api/history/bookmark - Toggle bookmark status
export async function PATCH(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id')

    if (!userId) {
      return NextResponse.json(
        { error: 'Missing user ID header' },
        { status: 400 }
      )
    }

    const body = await request.json()
    const { entryId, bookmarked } = body as { entryId: string; bookmarked: boolean }

    if (!entryId || typeof bookmarked !== 'boolean') {
      return NextResponse.json(
        { error: 'Missing required fields: entryId and bookmarked' },
        { status: 400 }
      )
    }

    const redis = await getRedisClient()
    const historyKey = `history:${userId}`

    // Get all entries
    const entries = await redis.zRange(historyKey, 0, -1, { REV: true })

    let updated = false
    const updatedEntries: Array<{ score: number; value: string }> = []

    for (const entry of entries) {
      try {
        const parsed = JSON.parse(entry) as HistoryEntry

        if (parsed.id === entryId) {
          parsed.bookmarked = bookmarked
          updated = true
        }

        updatedEntries.push({
          score: parsed.timestamp,
          value: JSON.stringify(parsed),
        })
      } catch (err) {
        console.error('Failed to parse history entry:', err)
      }
    }

    if (!updated) {
      return NextResponse.json(
        { error: 'Entry not found' },
        { status: 404 }
      )
    }

    // Replace all entries (Redis doesn't support updating in sorted set)
    await redis.del(historyKey)
    if (updatedEntries.length > 0) {
      await redis.zAdd(historyKey, updatedEntries)
      await redis.expire(historyKey, HISTORY_TTL)
    }

    return NextResponse.json({
      success: true,
      bookmarked,
    })
  } catch (error) {
    console.error('Error toggling bookmark:', error)
    return NextResponse.json(
      { error: 'Failed to toggle bookmark' },
      { status: 500 }
    )
  }
}
