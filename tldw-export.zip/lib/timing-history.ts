/**
 * Timing history utility to track actual request times and adapt estimates
 * Stores timing data in localStorage for persistence across sessions
 */

export interface TimingRecord {
  summaryLength: 'brief' | 'detailed' | 'comprehensive'
  fetchTime: number // seconds
  processTime: number // seconds
  generateTime: number // seconds
  totalTime: number // seconds
  timestamp: number // milliseconds since epoch
}

export interface TimingStats {
  summaryLength: 'brief' | 'detailed' | 'comprehensive'
  avgFetchTime: number
  avgProcessTime: number
  avgGenerateTime: number
  avgTotalTime: number
  count: number
}

const STORAGE_KEY = 'tldr_timing_history'
const MAX_RECORDS = 50 // Keep last 50 requests per length

/**
 * Get all timing records for a specific summary length
 */
export function getTimingRecords(summaryLength: 'brief' | 'detailed' | 'comprehensive'): TimingRecord[] {
  try {
    const data = localStorage.getItem(STORAGE_KEY)
    if (!data) return []

    const allRecords: TimingRecord[] = JSON.parse(data)
    return allRecords.filter((r) => r.summaryLength === summaryLength).slice(-MAX_RECORDS)
  } catch {
    return []
  }
}

/**
 * Calculate statistics from timing records
 */
export function getTimingStats(summaryLength: 'brief' | 'detailed' | 'comprehensive'): TimingStats {
  const records = getTimingRecords(summaryLength)

  if (records.length === 0) {
    // Return default estimates if no data
    const defaults: Record<'brief' | 'detailed' | 'comprehensive', Omit<TimingStats, 'summaryLength' | 'count'>> = {
      brief: { avgFetchTime: 3, avgProcessTime: 4, avgGenerateTime: 13, avgTotalTime: 20 },
      detailed: { avgFetchTime: 3, avgProcessTime: 4, avgGenerateTime: 28, avgTotalTime: 35 },
      comprehensive: { avgFetchTime: 3, avgProcessTime: 4, avgGenerateTime: 43, avgTotalTime: 50 },
    }

    return {
      summaryLength,
      ...defaults[summaryLength],
      count: 0,
    }
  }

  const avgFetchTime = Math.round(records.reduce((sum, r) => sum + r.fetchTime, 0) / records.length)
  const avgProcessTime = Math.round(records.reduce((sum, r) => sum + r.processTime, 0) / records.length)
  const avgGenerateTime = Math.round(records.reduce((sum, r) => sum + r.generateTime, 0) / records.length)
  const avgTotalTime = Math.round(records.reduce((sum, r) => sum + r.totalTime, 0) / records.length)

  return {
    summaryLength,
    avgFetchTime,
    avgProcessTime,
    avgGenerateTime,
    avgTotalTime,
    count: records.length,
  }
}

/**
 * Record a completed request's timing
 */
export function recordTiming(
  summaryLength: 'brief' | 'detailed' | 'comprehensive',
  fetchTime: number,
  processTime: number,
  generateTime: number
): void {
  try {
    const data = localStorage.getItem(STORAGE_KEY)
    const allRecords: TimingRecord[] = data ? JSON.parse(data) : []

    const newRecord: TimingRecord = {
      summaryLength,
      fetchTime,
      processTime,
      generateTime,
      totalTime: fetchTime + processTime + generateTime,
      timestamp: Date.now(),
    }

    allRecords.push(newRecord)

    // Keep only last 200 records total (mix of all lengths)
    const trimmed = allRecords.slice(-200)
    localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed))
  } catch {
    // Silently fail if localStorage is unavailable
  }
}

/**
 * Clear all timing history (for testing/reset)
 */
export function clearTimingHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEY)
  } catch {
    // Silently fail
  }
}
