'use client'

import { useState, useEffect } from 'react'
import { getUserId } from '@/lib/user-identity'
import type { HistoryEntry } from '@/lib/history.types'

interface HistoryPanelProps {
  onSelectEntry: (entry: HistoryEntry) => void
  isOpen: boolean
  onClose: () => void
}

export function HistoryPanel({ onSelectEntry, isOpen, onClose }: HistoryPanelProps) {
  const [entries, setEntries] = useState<HistoryEntry[]>([])
  const [loading, setLoading] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [filterBookmarked, setFilterBookmarked] = useState(false)

  useEffect(() => {
    if (isOpen) {
      loadHistory()
    }
  }, [isOpen])

  const loadHistory = async () => {
    setLoading(true)
    try {
      const userId = getUserId()
      const response = await fetch('/api/history', {
        headers: {
          'x-user-id': userId,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setEntries(data.entries || [])
      }
    } catch (error) {
      console.error('Failed to load history:', error)
    } finally {
      setLoading(false)
    }
  }

  const toggleBookmark = async (entryId: string, currentStatus: boolean) => {
    try {
      const userId = getUserId()
      const response = await fetch('/api/history/bookmark', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': userId,
        },
        body: JSON.stringify({
          entryId,
          bookmarked: !currentStatus,
        }),
      })

      if (response.ok) {
        setEntries(
          entries.map((entry) =>
            entry.id === entryId ? { ...entry, bookmarked: !currentStatus } : entry
          )
        )
      }
    } catch (error) {
      console.error('Failed to toggle bookmark:', error)
    }
  }

  const clearHistory = async () => {
    if (!confirm('Are you sure you want to clear all history?')) {
      return
    }

    try {
      const userId = getUserId()
      const response = await fetch('/api/history', {
        method: 'DELETE',
        headers: {
          'x-user-id': userId,
        },
      })

      if (response.ok) {
        setEntries([])
      }
    } catch (error) {
      console.error('Failed to clear history:', error)
    }
  }

  const filteredEntries = entries.filter((entry) => {
    if (filterBookmarked && !entry.bookmarked) return false
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      return (
        entry.videoId.toLowerCase().includes(query) ||
        entry.title?.toLowerCase().includes(query) ||
        entry.summary.toLowerCase().includes(query)
      )
    }
    return true
  })

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-900">Summary History</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>

          {/* Search and filters */}
          <div className="flex gap-3">
            <input
              type="text"
              placeholder="Search videos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none"
            />
            <button
              onClick={() => setFilterBookmarked(!filterBookmarked)}
              className={`px-4 py-2 rounded-lg font-medium transition ${
                filterBookmarked
                  ? 'bg-yellow-100 text-yellow-800 border-2 border-yellow-400'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              ⭐ Bookmarked
            </button>
            <button
              onClick={clearHistory}
              className="px-4 py-2 bg-red-100 text-red-700 rounded-lg font-medium hover:bg-red-200 transition"
            >
              Clear All
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {loading ? (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600"></div>
              <p className="mt-4 text-gray-600">Loading history...</p>
            </div>
          ) : filteredEntries.length === 0 ? (
            <div className="text-center py-12">
              <svg
                className="mx-auto h-12 w-12 text-gray-400"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                />
              </svg>
              <p className="mt-4 text-gray-600">
                {searchQuery || filterBookmarked ? 'No matching entries found' : 'No history yet'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="border border-gray-200 rounded-lg p-4 hover:border-indigo-300 hover:shadow-md transition cursor-pointer"
                  onClick={() => onSelectEntry(entry)}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-semibold text-gray-900">
                          {entry.title || `Video ${entry.videoId}`}
                        </h3>
                        <button
                          onClick={(e) => {
                            e.stopPropagation()
                            toggleBookmark(entry.id, entry.bookmarked)
                          }}
                          className="text-xl hover:scale-110 transition"
                        >
                          {entry.bookmarked ? '⭐' : '☆'}
                        </button>
                      </div>
                      <p className="text-sm text-gray-500 mb-2">
                        {new Date(entry.timestamp).toLocaleString()} · {entry.videoId}
                      </p>
                      <div className="flex gap-2">
                        <span className="px-2 py-1 bg-indigo-100 text-indigo-800 rounded text-xs font-medium capitalize">
                          {entry.length}
                        </span>
                        {entry.transcriptLanguage && (
                          <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-medium">
                            {entry.transcriptLanguage}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 line-clamp-2">{entry.summary}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
