import { createClient, RedisClientType } from 'redis'

let redisClient: RedisClientType | null = null
let shutdownHandlersRegistered = false

export async function getRedisClient(): Promise<RedisClientType> {
  if (redisClient) {
    return redisClient
  }

  redisClient = createClient({
    url: process.env.REDIS_URL || 'redis://localhost:6379',
  })

  redisClient.on('error', (err) => {
    console.error('Redis client error:', err)
  })

  redisClient.on('connect', () => {
    console.log('Connected to Redis')
  })

  await redisClient.connect()

  // Register shutdown handlers only once
  if (!shutdownHandlersRegistered) {
    registerShutdownHandlers()
    shutdownHandlersRegistered = true
  }

  return redisClient
}

export async function closeRedisClient(): Promise<void> {
  if (redisClient) {
    console.log('Closing Redis connection')
    await redisClient.disconnect()
    redisClient = null
  }
}

function registerShutdownHandlers(): void {
  // Handle process termination signals
  process.on('SIGTERM', async () => {
    console.log('SIGTERM signal received: closing Redis connection')
    await closeRedisClient()
    process.exit(0)
  })

  process.on('SIGINT', async () => {
    console.log('SIGINT signal received: closing Redis connection')
    await closeRedisClient()
    process.exit(0)
  })
}
