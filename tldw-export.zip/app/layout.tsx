import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'TLDW YT Video - Video Summarizer',
  description: 'Get instant summaries of YouTube videos with customizable length',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className="bg-gray-50">
        {children}
      </body>
    </html>
  )
}
