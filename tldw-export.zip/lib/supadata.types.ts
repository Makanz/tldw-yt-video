/**
 * TypeScript type definitions for Supadata YouTube transcript API
 * Helps eliminate type ambiguity when working with Supadata responses
 */

export interface TranscriptChunk {
  text: string
  startTime?: number
  endTime?: number
}

export interface SuperdataYoutubeTranscriptResponse {
  content: string | TranscriptChunk[]
  language?: string
  videoId?: string
  title?: string
}

export interface SuperdataTranscriptResult {
  content: string | TranscriptChunk[]
  language?: string
  videoId?: string
  title?: string
}
