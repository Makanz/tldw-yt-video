# Multi-Language Support

YouTube TLDR now supports transcripts and summaries in multiple languages, allowing you to work with international video content.

## Features

### 1. **Transcript Language Selection**
- **Auto-detect** (default): Automatically detects the language of the video's captions
- **Manual selection**: Choose from 19 supported languages if you know the video has specific language captions

### 2. **Summary Language Selection**
- Generate summaries in any of the 19 supported languages
- Default: English
- Cross-language translation: Transcript in one language, summary in another (e.g., Spanish video → English summary)

### 3. **Intelligent Caching**
- Transcripts are cached per video AND per language
- Cache key format: `transcript:{videoId}:{languageCode}`
- 7-day TTL (same as before)
- Reduces API calls for frequently accessed videos in different languages

## Supported Languages

| Language | Code | Native Name |
|----------|------|-------------|
| English | en | English |
| Spanish | es | Español |
| French | fr | Français |
| German | de | Deutsch |
| Italian | it | Italiano |
| Portuguese | pt | Português |
| Dutch | nl | Nederlands |
| Polish | pl | Polski |
| Russian | ru | Русский |
| Japanese | ja | 日本語 |
| Korean | ko | 한국어 |
| Chinese | zh | 中文 |
| Arabic | ar | العربية |
| Hindi | hi | हिन्दी |
| Turkish | tr | Türkçe |
| Swedish | sv | Svenska |
| Danish | da | Dansk |
| Norwegian | no | Norsk |
| Finnish | fi | Suomi |

## How It Works

### Frontend (page.tsx)
1. User selects **Transcript Language** (default: auto-detect)
2. User selects **Summary Language** (default: English)
3. Form submission includes both language preferences
4. Detected language is displayed as a badge in the summary results

### Backend (api/summarize/route.ts)
1. **Transcript Fetching**:
   - Check Redis cache for transcript with specific language
   - If cache miss: Fetch from Supadata API with language parameter
   - Store transcript with metadata (language code, detected language name)

2. **Prompt Engineering**:
   - If transcript is non-English and summary is English: Adds translation instruction
   - If summary language differs from English: Adds target language instruction
   - OpenAI GPT-4o-mini handles both translation and summarization

3. **Response**:
   - Returns summary with metadata:
     - `transcriptLanguage`: Human-readable language name (e.g., "Spanish")
     - `transcriptLanguageCode`: ISO language code (e.g., "es")
     - `summaryLanguage`: Requested summary language

## Usage Examples

### Example 1: Auto-detect with English Summary
```
Video: Spanish cooking tutorial
Transcript Language: Auto-detect
Summary Language: English

Result: Automatically detects Spanish transcript → Generates English summary
```

### Example 2: Specific Language Selection
```
Video: Multilingual video with multiple caption options
Transcript Language: French (fr)
Summary Language: English

Result: Fetches French captions → Generates English summary
```

### Example 3: Same-Language Processing
```
Video: German tech review
Transcript Language: German (de)
Summary Language: German (Deutsch)

Result: Fetches German transcript → Generates German summary
```

### Example 4: Non-English to Non-English
```
Video: Japanese anime discussion
Transcript Language: Auto-detect
Summary Language: Spanish (Español)

Result: Detects Japanese → Generates Spanish summary
```

## API Changes

### Request Body
```json
{
  "url": "https://www.youtube.com/watch?v=...",
  "length": "detailed",
  "transcriptLanguage": "es",  // Optional: omit for auto-detect
  "summaryLanguage": "English"  // Required: language name
}
```

### Response Body
```json
{
  "success": true,
  "videoId": "dQw4w9WgXcQ",
  "summary": "...",
  "length": "detailed",
  "transcriptLanguage": "Spanish",
  "transcriptLanguageCode": "es",
  "summaryLanguage": "English"
}
```

## Error Handling

### Common Errors
1. **No captions in requested language**: 
   - Error: "Could not extract transcript. The video may not have captions available in the requested language."
   - Solution: Try auto-detect or a different language

2. **Video has no captions**:
   - Error: Same as above
   - Solution: Only works with videos that have public captions

3. **Invalid language code**:
   - Handled gracefully: Falls back to auto-detect

## Performance Considerations

### Cache Efficiency
- Each language creates a separate cache entry
- Popular videos in multiple languages = multiple cache entries
- Example: English video requested in both English and Spanish = 2 cache entries

### API Costs
- Supadata API: Same cost per transcript fetch (regardless of language)
- OpenAI API: Translation + summarization may use more tokens than summarization alone
- Recommendation: Use comprehensive summaries for translated content to capture nuances

### Typical Response Times
| Scenario | Time (cached) | Time (uncached) |
|----------|---------------|-----------------|
| Same language | 3-7s | 8-15s |
| Translation required | 4-8s | 10-18s |
| Auto-detect | 3-7s | 8-15s |

## Development Guide

### Adding a New Language

1. **Update `lib/language-utils.ts`**:
```typescript
export const SUPPORTED_LANGUAGES: Language[] = [
  // ... existing languages
  { code: 'xx', name: 'New Language', nativeName: 'Native Name' },
]
```

2. **Test with a video**:
   - Find a YouTube video with captions in the new language
   - Test auto-detect and manual selection
   - Verify cache key generation

3. **No other changes needed**:
   - UI automatically updates with new language in dropdowns
   - Backend handles any language code
   - OpenAI GPT-4o-mini supports 50+ languages natively

### Debugging Language Issues

1. **Check console logs**:
   - "Cache hit/miss for video {videoId}"
   - "Transcript length: X, Language: Y"

2. **Inspect Redis cache**:
```bash
redis-cli
> KEYS transcript:*
> GET transcript:VIDEO_ID:es
```

3. **Test Supadata response**:
   - Check if `result.language` is populated
   - Verify language code format (ISO 639-1)

## Limitations

1. **Supadata API**: Must support the requested language
2. **YouTube Captions**: Video must have captions in the requested language
3. **Auto-generated captions**: Quality depends on YouTube's speech recognition
4. **Translation accuracy**: Depends on OpenAI's multilingual capabilities
5. **Character sets**: Some languages (Arabic, Chinese) may have display issues in certain terminals

## Future Enhancements

1. **Language detection confidence score**: Show reliability of auto-detection
2. **Multiple caption tracks**: Support videos with multiple language options (show available languages)
3. **Dialect support**: Region-specific variants (e.g., es-ES vs es-MX)
4. **Batch translation**: Summarize multiple videos in different languages
5. **Custom language preferences**: Remember user's preferred languages
