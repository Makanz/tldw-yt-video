// Client-side user identity management
// Generates and stores a unique user ID in localStorage

export function getUserId(): string {
  if (typeof window === 'undefined') {
    throw new Error('getUserId() can only be called on the client side')
  }

  const USER_ID_KEY = 'tldw_user_id'
  let userId = localStorage.getItem(USER_ID_KEY)

  if (!userId) {
    // Generate a unique user ID: timestamp + random string
    userId = `user_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`
    localStorage.setItem(USER_ID_KEY, userId)
  }

  return userId
}

export function clearUserId(): void {
  if (typeof window === 'undefined') {
    return
  }
  localStorage.removeItem('tldw_user_id')
}
