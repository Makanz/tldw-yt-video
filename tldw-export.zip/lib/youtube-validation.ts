/**
 * YouTube URL validation and video ID extraction utilities
 */

/**
 * Validates if a string is a valid YouTube URL
 * Supports multiple YouTube URL formats
 */
export function isValidYouTubeUrl(url: string): boolean {
  if (!url || typeof url !== 'string') {
    return false
  }

  // Trim whitespace
  const trimmedUrl = url.trim()

  if (!trimmedUrl) {
    return false
  }

  // YouTube URL patterns
  const youtubePatterns = [
    /^https?:\/\/(?:www\.)?youtube\.com\/watch\?(?:.*&)?v=[a-zA-Z0-9_-]{11}(?:&|$)/,
    /^https?:\/\/(?:www\.)?youtu\.be\/[a-zA-Z0-9_-]{11}(?:[?]|$)/,
    /^https?:\/\/(?:www\.)?youtube\.com\/embed\/[a-zA-Z0-9_-]{11}(?:[?]|$)/,
    /^https?:\/\/(?:www\.)?youtube\.com\/v\/[a-zA-Z0-9_-]{11}(?:[?]|$)/,
  ]

  return youtubePatterns.some((pattern) => pattern.test(trimmedUrl))
}

/**
 * Validates if a string is a properly formatted URL
 */
function isValidUrl(url: string): boolean {
  try {
    new URL(url)
    return true
  } catch {
    return false
  }
}

/**
 * Extracts video ID from a YouTube URL
 * Throws an error if the URL is invalid or doesn't contain a valid video ID
 */
export function extractVideoId(url: string): string {
  if (!url || typeof url !== 'string') {
    throw new Error('URL must be a non-empty string')
  }

  const trimmedUrl = url.trim()

  // First, validate it's a proper URL format
  if (!isValidUrl(trimmedUrl)) {
    throw new Error('Invalid URL format. Please enter a valid YouTube URL.')
  }

  // Then validate it's a YouTube URL
  if (!isValidYouTubeUrl(trimmedUrl)) {
    throw new Error(
      'Invalid YouTube URL. Please use a valid YouTube link (youtube.com, youtu.be, or youtube.com/embed)',
    )
  }

  // Extract video ID from various YouTube URL formats
  const patterns = [
    /youtube\.com\/watch\?(?:.*&)?v=([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/v\/([a-zA-Z0-9_-]{11})/,
  ]

  for (const pattern of patterns) {
    const match = trimmedUrl.match(pattern)
    if (match && match[1]) {
      return match[1]
    }
  }

  throw new Error('Could not extract video ID from URL. Please check the URL format.')
}

/**
 * Validates video ID format
 */
export function isValidVideoId(videoId: string): boolean {
  if (!videoId || typeof videoId !== 'string') {
    return false
  }

  // YouTube video IDs are 11 characters long, containing only alphanumeric characters, hyphens, and underscores
  return /^[a-zA-Z0-9_-]{11}$/.test(videoId)
}

/**
 * Provides helpful error message based on URL format
 */
export function getUrlValidationError(url: string): string | null {
  if (!url) {
    return 'Please enter a YouTube URL'
  }

  const trimmedUrl = url.trim()

  if (!trimmedUrl) {
    return 'URL cannot be empty or contain only whitespace'
  }

  if (!isValidUrl(trimmedUrl)) {
    return 'Invalid URL format. Make sure it starts with http:// or https://'
  }

  try {
    const urlObj = new URL(trimmedUrl)
    const host = urlObj.hostname

    // Check if it's a YouTube domain
    if (!host.includes('youtube.com') && !host.includes('youtu.be')) {
      return 'This URL is not from YouTube. Please use a YouTube video link.'
    }

    // Check for valid video ID
    if (!isValidYouTubeUrl(trimmedUrl)) {
      return 'Invalid YouTube URL format. Make sure the URL contains a valid video ID.'
    }
  } catch {
    return 'Invalid URL format'
  }

  return null
}
