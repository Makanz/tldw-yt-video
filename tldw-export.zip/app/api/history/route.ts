import { NextRequest, NextResponse } from 'next/server'
import { getRedisClient } from '@/lib/redis'
import type { HistoryEntry } from '@/lib/history.types'

const HISTORY_TTL = 86400 * 30 // 30 days
const MAX_HISTORY_ENTRIES = 100

// GET /api/history - Retrieve user's history
export async function GET(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id')

    if (!userId) {
      return NextResponse.json(
        { error: 'Missing user ID header' },
        { status: 400 }
      )
    }

    const redis = await getRedisClient()
    const historyKey = `history:${userId}`

    // Get all history entries (sorted set by timestamp)
    const entries = await redis.zRange(historyKey, 0, -1, { REV: true })

    const historyEntries: HistoryEntry[] = []
    for (const entry of entries) {
      try {
        const parsed = JSON.parse(entry) as HistoryEntry
        historyEntries.push(parsed)
      } catch (err) {
        console.error('Failed to parse history entry:', err)
      }
    }

    return NextResponse.json({
      success: true,
      entries: historyEntries,
      total: historyEntries.length,
    })
  } catch (error) {
    console.error('Error fetching history:', error)
    return NextResponse.json(
      { error: 'Failed to fetch history' },
      { status: 500 }
    )
  }
}

// POST /api/history - Add entry to user's history
export async function POST(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id')

    if (!userId) {
      return NextResponse.json(
        { error: 'Missing user ID header' },
        { status: 400 }
      )
    }

    const body = await request.json()
    const { videoId, url, summary, length, transcriptLanguage, summaryLanguage, title, thumbnail } = body as Partial<HistoryEntry>

    if (!videoId || !url || !summary || !length) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const redis = await getRedisClient()
    const historyKey = `history:${userId}`
    const timestamp = Date.now()

    const entry: HistoryEntry = {
      id: `${videoId}_${timestamp}`,
      videoId,
      url,
      title,
      thumbnail,
      summary,
      length,
      transcriptLanguage,
      summaryLanguage,
      timestamp,
      bookmarked: false,
    }

    // Add to sorted set (score = timestamp)
    await redis.zAdd(historyKey, {
      score: timestamp,
      value: JSON.stringify(entry),
    })

    // Trim to max entries (keep most recent)
    const count = await redis.zCard(historyKey)
    if (count > MAX_HISTORY_ENTRIES) {
      await redis.zRemRangeByRank(historyKey, 0, count - MAX_HISTORY_ENTRIES - 1)
    }

    // Set TTL on the key
    await redis.expire(historyKey, HISTORY_TTL)

    return NextResponse.json({
      success: true,
      entry,
    })
  } catch (error) {
    console.error('Error adding to history:', error)
    return NextResponse.json(
      { error: 'Failed to add to history' },
      { status: 500 }
    )
  }
}

// DELETE /api/history - Clear user's history
export async function DELETE(request: NextRequest) {
  try {
    const userId = request.headers.get('x-user-id')

    if (!userId) {
      return NextResponse.json(
        { error: 'Missing user ID header' },
        { status: 400 }
      )
    }

    const redis = await getRedisClient()
    const historyKey = `history:${userId}`

    await redis.del(historyKey)

    return NextResponse.json({
      success: true,
      message: 'History cleared',
    })
  } catch (error) {
    console.error('Error clearing history:', error)
    return NextResponse.json(
      { error: 'Failed to clear history' },
      { status: 500 }
    )
  }
}
