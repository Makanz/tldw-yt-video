'use client'

import { useEffect, useState } from 'react'
import { getTimingStats, type TimingStats } from '@/lib/timing-history'

interface LoadingStateProps {
  summaryLength: 'brief' | 'detailed' | 'comprehensive'
}

type LoadingPhase = 'fetching' | 'processing' | 'generating'

export function LoadingState({ summaryLength }: LoadingStateProps) {
  const [elapsedSeconds, setElapsedSeconds] = useState(0)
  const [currentPhase, setCurrentPhase] = useState<LoadingPhase>('fetching')
  const [timingStats, setTimingStats] = useState<TimingStats | null>(null)

  // Load timing stats from history on mount
  useEffect(() => {
    const stats = getTimingStats(summaryLength)
    setTimingStats(stats)
  }, [summaryLength])

  // Get estimated times based on historical data
  const estimatedTotal = timingStats?.avgTotalTime ?? 35

  // Calculate phase thresholds based on historical data
  const fetchThreshold = timingStats?.avgFetchTime ?? 3
  const processThreshold = fetchThreshold + (timingStats?.avgProcessTime ?? 4)

  // Update elapsed time and phase
  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds((prev) => {
        const newSeconds = prev + 1

        // Update phase based on actual phase durations
        if (newSeconds < fetchThreshold) {
          setCurrentPhase('fetching')
        } else if (newSeconds < processThreshold) {
          setCurrentPhase('processing')
        } else {
          setCurrentPhase('generating')
        }

        return newSeconds
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [fetchThreshold, processThreshold])

  // Calculate progress percent, capping at 90% for final stages
  const progressPercent = Math.min((elapsedSeconds / estimatedTotal) * 100, 90)

  const phaseMessages: Record<LoadingPhase, string> = {
    fetching: 'Fetching video transcript...',
    processing: 'Processing content...',
    generating: 'Generating summary...',
  }

  const formatTime = (seconds: number): string => {
    if (seconds < 60) {
      return `${seconds}s`
    }
    const minutes = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${minutes}m ${secs}s`
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-2xl p-8 max-w-md w-full mx-4">
        <div className="flex flex-col items-center space-y-6">
          {/* Spinning Loader */}
          <div className="relative w-16 h-16">
            <svg
              className="animate-spin absolute inset-0"
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="opacity-75 text-indigo-600"
                fill="currentColor"
                d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
              />
            </svg>
          </div>

          {/* Phase Message */}
          <div className="text-center">
            <p className="text-lg font-semibold text-gray-900">{phaseMessages[currentPhase]}</p>
          </div>

          {/* Progress Bar */}
          <div className="w-full space-y-2">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 text-center">{Math.round(progressPercent)}% complete</p>
          </div>

          {/* Time Information */}
          <div className="w-full pt-4 border-t border-gray-200">
            <div className="flex justify-between items-center text-sm">
              <span className="text-gray-600">Elapsed: {formatTime(elapsedSeconds)}</span>
              <span className="text-gray-500">Est. {formatTime(estimatedTotal)}</span>
            </div>
          </div>

          {/* Phase Indicators */}
          <div className="w-full flex justify-between items-center pt-4">
            {(['fetching', 'processing', 'generating'] as const).map((phase) => {
              const phaseThresholds = {
                fetching: 0,
                processing: fetchThreshold,
                generating: processThreshold,
              }
              const isCompleted = elapsedSeconds >= phaseThresholds[phase] && currentPhase !== phase
              const isCurrent = currentPhase === phase

              return (
                <div key={phase} className="flex flex-col items-center gap-1">
                  <div
                    className={`w-3 h-3 rounded-full transition-all ${
                      isCurrent ? 'bg-indigo-600 ring-2 ring-indigo-300' : isCompleted ? 'bg-green-500' : 'bg-gray-300'
                    }`}
                  />
                  <span className="text-xs text-gray-600 capitalize">{phase}</span>
                </div>
              )
            })}
          </div>

          {/* Helpful Tips */}
          {elapsedSeconds > 15 && (
            <div className="w-full pt-4 border-t border-gray-200">
              <p className="text-xs text-gray-500 text-center italic">
                Taking a bit longer than expected? Complex videos may require additional processing time.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
