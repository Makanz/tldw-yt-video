// Types for user history feature

export interface HistoryEntry {
  id: string
  videoId: string
  url: string
  title?: string
  thumbnail?: string
  summary: string
  length: 'brief' | 'detailed' | 'comprehensive'
  transcriptLanguage?: string
  summaryLanguage?: string
  timestamp: number
  bookmarked: boolean
}

export interface HistoryListResponse {
  success: boolean
  entries: HistoryEntry[]
  total: number
}
