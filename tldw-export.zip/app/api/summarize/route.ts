import { NextRequest, NextResponse } from 'next/server'
import OpenAI from 'openai'
import { Supadata } from '@supadata/js'
import { getRedisClient } from '@/lib/redis'
import { extractVideoId, isValidYouTubeUrl } from '@/lib/youtube-validation'
import { detectLanguageFromCode } from '@/lib/language-utils'
import type { SuperdataTranscriptResult } from '@/lib/supadata.types'

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

const supadata = new Supadata({
  apiKey: process.env.SUPADATA_API_KEY || '',
})

// Cache configuration
const TRANSCRIPT_CACHE_TTL = 86400 * 7 // 7 days in seconds

interface TranscriptWithLanguage {
  transcript: string
  detectedLanguage: string
  languageCode: string
}

async function getYouTubeTranscript(
  videoId: string, 
  url: string,
  preferredLanguage?: string
): Promise<TranscriptWithLanguage> {
  const languageSuffix = preferredLanguage ? `:${preferredLanguage}` : ''
  const cacheKey = `transcript:${videoId}${languageSuffix}`

  try {
    // Try to get from cache first
    const redis = await getRedisClient()
    const cachedData = await redis.get(cacheKey)

    if (cachedData && typeof cachedData === 'string') {
      console.log(`Cache hit for video ${videoId}, length: ${cachedData.length}`)
      try {
        const parsed = JSON.parse(cachedData) as TranscriptWithLanguage
        return parsed
      } catch {
        // Legacy cache format (plain string), treat as English
        return {
          transcript: cachedData,
          detectedLanguage: 'English',
          languageCode: 'en'
        }
      }
    }

    console.log(`Cache miss for video ${videoId}, fetching from Supadata`)
    console.log('Fetching transcript from Supadata for URL:', url)

    const requestOptions: { url: string; text: boolean; lang?: string } = {
      url,
      text: true,
    }

    // Add language parameter if specified
    if (preferredLanguage) {
      requestOptions.lang = preferredLanguage
    }

    const result = (await supadata.youtube.transcript(requestOptions)) as SuperdataTranscriptResult

    if (!result || !result.content) {
      throw new Error('No transcript returned from Supadata')
    }

    // Content can be either string or TranscriptChunk[], ensure it's a string
    let transcript: string
    if (typeof result.content === 'string') {
      transcript = result.content
    } else {
      // If it's TranscriptChunk[], join the text parts
      transcript = result.content
        .map((chunk): string => chunk.text)
        .join(' ')
    }

    transcript = transcript.trim()

    if (!transcript) {
      throw new Error('Transcript text is empty')
    }

    // Detect language from response
    const languageCode = result.language || preferredLanguage || 'en'
    const detectedLanguage = detectLanguageFromCode(languageCode)

    console.log('Transcript length:', transcript.length, 'Language:', detectedLanguage)

    const transcriptData: TranscriptWithLanguage = {
      transcript,
      detectedLanguage,
      languageCode
    }

    // Store in cache with TTL
    await redis.setEx(cacheKey, TRANSCRIPT_CACHE_TTL, JSON.stringify(transcriptData))
    console.log(`Cached transcript for video ${videoId} in ${detectedLanguage}`)

    return transcriptData
  } catch (error) {
    console.error('Error fetching transcript:', error)

    if (error instanceof Error && error.message.includes('transcript')) {
      throw new Error('Could not extract transcript. The video may not have captions available in the requested language.')
    }

    throw new Error('Could not fetch transcript from Supadata')
  }
}


function generatePrompt(
  transcript: string, 
  length: 'brief' | 'detailed' | 'comprehensive',
  transcriptLanguage: string,
  targetLanguage: string
): string {
  const lengthInstructions = {
    brief: 'Provide a concise summary in 2-3 paragraphs with the main points.',
    detailed: 'Provide a detailed summary in 5-7 paragraphs covering the main topics and key points.',
    comprehensive: 'Provide a comprehensive summary covering all major topics, key arguments, and conclusions. Use paragraphs and bullet points as needed.',
  }

  const translationNote = transcriptLanguage !== 'English' && targetLanguage === 'en'
    ? `\n\nNote: This transcript is in ${transcriptLanguage}. Please provide the summary in English.`
    : targetLanguage !== 'en'
    ? `\n\nNote: Please provide the summary in ${targetLanguage}.`
    : ''

  return `You are an expert video summarizer. Your task is to create a summary of the following YouTube video transcript.

${lengthInstructions[length]}

Format the summary clearly and make it easy to read. Focus on the most important information and insights.${translationNote}

Video Transcript:
${transcript}

Please provide the summary now:`
}

export async function POST(request: NextRequest) {
  try {
    // Parse and validate request body
    let requestBody: unknown
    try {
      requestBody = await request.json()
    } catch {
      return NextResponse.json(
        { error: 'Invalid JSON in request body' },
        { status: 400 }
      )
    }

    const { url, length, transcriptLanguage, summaryLanguage } = requestBody as Record<string, unknown>

    // Validate required parameters
    if (!url || !length) {
      return NextResponse.json(
        { error: 'Missing required parameters: url and length' },
        { status: 400 }
      )
    }

    // Validate URL is a string
    if (typeof url !== 'string') {
      return NextResponse.json(
        { error: 'URL must be a string' },
        { status: 400 }
      )
    }

    // Validate length is a string
    if (typeof length !== 'string') {
      return NextResponse.json(
        { error: 'Length must be a string' },
        { status: 400 }
      )
    }

    // Validate length value
    const validLengths = ['brief', 'detailed', 'comprehensive'] as const
    if (!validLengths.includes(length as 'brief' | 'detailed' | 'comprehensive')) {
      return NextResponse.json(
        { error: `Length must be one of: ${validLengths.join(', ')}` },
        { status: 400 }
      )
    }

    // Validate YouTube URL format
    if (!isValidYouTubeUrl(url)) {
      return NextResponse.json(
        { error: 'Invalid YouTube URL. Please provide a valid YouTube video link.' },
        { status: 400 }
      )
    }

    // Extract and validate video ID
    let videoId: string
    try {
      videoId = extractVideoId(url)
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Could not extract video ID'
      return NextResponse.json(
        { error: errorMessage },
        { status: 400 }
      )
    }

    // Validate language codes if provided
    const requestedTranscriptLang = typeof transcriptLanguage === 'string' ? transcriptLanguage : undefined
    const requestedSummaryLang = typeof summaryLanguage === 'string' ? summaryLanguage : 'English'

    // Get transcript (with caching and language support)
    const transcriptData = await getYouTubeTranscript(videoId, url, requestedTranscriptLang)

    if (!transcriptData.transcript || transcriptData.transcript.trim().length === 0) {
      return NextResponse.json(
        { error: 'Could not extract transcript. The video may not have captions available in the requested language.' },
        { status: 400 }
      )
    }

    // Generate summary using OpenAI GPT
    const prompt = generatePrompt(
      transcriptData.transcript, 
      length as 'brief' | 'detailed' | 'comprehensive',
      transcriptData.detectedLanguage,
      requestedSummaryLang
    )

    const message = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      max_tokens: length === 'brief' ? 500 : length === 'detailed' ? 1000 : 2000,
      messages: [
        {
          role: 'user',
          content: prompt,
        },
      ],
    })

    const summary = message.choices
      .filter((choice) => choice.message?.content)
      .map((choice) => choice.message?.content || '')
      .join('\n')

    return NextResponse.json({
      success: true,
      videoId,
      summary,
      length,
      transcriptLanguage: transcriptData.detectedLanguage,
      transcriptLanguageCode: transcriptData.languageCode,
      summaryLanguage: requestedSummaryLang,
    })
  } catch (error) {
    console.error('Error in summarize endpoint:', error)
    const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred'
    return NextResponse.json(
      { error: errorMessage },
      { status: 500 }
    )
  }
}
