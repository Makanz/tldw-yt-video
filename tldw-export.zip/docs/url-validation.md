# URL Validation Implementation

## Overview

This document describes the comprehensive URL validation system implemented for the TLDW YT Video application to prevent errors from malformed or invalid URLs.

## Problem Statement

The original implementation did not validate user input before attempting URL extraction, which could lead to:
- Malformed URLs causing unexpected errors
- Non-YouTube URLs being submitted to the API
- Edge cases with special characters not being handled properly

## Solution

A comprehensive validation system has been implemented with three layers:

1. **Client-side validation** - Real-time feedback as users type
2. **Server-side validation** - Defensive validation before processing
3. **URL extraction** - Robust video ID extraction with error handling

## Implementation Details

### Core Validation Module: `lib/youtube-validation.ts`

#### Functions

##### `isValidYouTubeUrl(url: string): boolean`
Validates if a string is a valid YouTube URL supporting multiple formats:
- `https://www.youtube.com/watch?v=VIDEO_ID`
- `https://youtu.be/VIDEO_ID`
- `https://www.youtube.com/embed/VIDEO_ID`
- `https://www.youtube.com/v/VIDEO_ID`

**Validation checks:**
- Non-empty string
- Proper URL scheme (http/https)
- Valid YouTube domain
- 11-character alphanumeric video ID

**Examples:**
```typescript
isValidYouTubeUrl('https://www.youtube.com/watch?v=dQw4w9WgXcQ') // ✓ true
isValidYouTubeUrl('https://youtu.be/dQw4w9WgXcQ') // ✓ true
isValidYouTubeUrl('https://google.com') // ✗ false
isValidYouTubeUrl('not-a-url') // ✗ false
```

##### `extractVideoId(url: string): string`
Extracts the 11-character video ID from a valid YouTube URL.

**Validation steps:**
1. Check input is a non-empty string
2. Validate URL format using standard URL constructor
3. Validate it's a YouTube URL using `isValidYouTubeUrl()`
4. Extract video ID using multiple regex patterns
5. Return video ID or throw descriptive error

**Throws on:**
- Empty or non-string input: "URL must be a non-empty string"
- Invalid URL format: "Invalid URL format. Please enter a valid YouTube URL."
- Non-YouTube URL: "Invalid YouTube URL. Please use a valid YouTube link..."
- No valid video ID: "Could not extract video ID from URL. Please check the URL format."

**Examples:**
```typescript
extractVideoId('https://www.youtube.com/watch?v=dQw4w9WgXcQ') // ✓ 'dQw4w9WgXcQ'
extractVideoId('https://youtu.be/dQw4w9WgXcQ?t=10') // ✓ 'dQw4w9WgXcQ'
extractVideoId('not-a-url') // ✗ throws "Invalid URL format..."
```

##### `isValidVideoId(videoId: string): boolean`
Validates that a video ID is exactly 11 characters containing only alphanumeric, hyphen, or underscore characters.

**Examples:**
```typescript
isValidVideoId('dQw4w9WgXcQ') // ✓ true
isValidVideoId('short') // ✗ false
isValidVideoId('dQw4w9Wg!') // ✗ false (invalid character)
```

##### `getUrlValidationError(url: string): string | null`
Provides helpful, user-friendly error messages for invalid URLs.

**Returns:**
- `null` for valid URLs
- Descriptive error message for invalid input

**Examples:**
```typescript
getUrlValidationError('https://www.youtube.com/watch?v=dQw4w9WgXcQ') // ✓ null
getUrlValidationError('') // ✗ "Please enter a YouTube URL"
getUrlValidationError('https://google.com') // ✗ "This URL is not from YouTube..."
getUrlValidationError('not-a-url') // ✗ "Invalid URL format..."
```

## Client-Side Integration: `app/page.tsx`

### State Management
Added `urlError` state to track validation errors:
```typescript
const [urlError, setUrlError] = useState('')
```

### Real-Time Validation
`handleUrlChange()` validates URLs as users type:
```typescript
const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const newUrl = e.target.value
  setUrl(newUrl)

  if (newUrl.trim()) {
    const validationError = getUrlValidationError(newUrl)
    setUrlError(validationError || '')
  } else {
    setUrlError('')
  }
}
```

### Form-Level Validation
`handleSubmit()` performs final validation before submission:
```typescript
const validationError = getUrlValidationError(url)
if (validationError) {
  setError(validationError)
  return
}

if (!isValidYouTubeUrl(url)) {
  setError('Please enter a valid YouTube URL.')
  return
}
```

### Visual Feedback
- URL input field shows red border when invalid
- Error message displays below the input field
- Submit button disabled when URL has validation errors

## Server-Side Integration: `app/api/summarize/route.ts`

### Validation Layers

1. **Request Parsing**
   - Validates JSON can be parsed
   - Returns 400 if malformed

2. **Parameter Validation**
   - Checks required fields exist
   - Validates types (string for url and length)

3. **Value Validation**
   - Validates length is one of: brief, detailed, comprehensive
   - Validates URL using `isValidYouTubeUrl()`

4. **Video ID Extraction**
   - Calls `extractVideoId()` with comprehensive error handling
   - Catches and returns specific error messages

### Error Responses

| Scenario | Status | Message |
|----------|--------|---------|
| Invalid JSON | 400 | "Invalid JSON in request body" |
| Missing parameters | 400 | "Missing required parameters: url and length" |
| URL not string | 400 | "URL must be a string" |
| Invalid YouTube URL | 400 | "Invalid YouTube URL..." |
| Cannot extract video ID | 400 | *(specific extraction error)* |
| Transcript not available | 400 | "Could not extract transcript..." |
| Server error | 500 | *(error message)* |

## Test Cases

### Valid URL Formats
- ✓ `https://www.youtube.com/watch?v=dQw4w9WgXcQ`
- ✓ `https://youtube.com/watch?v=dQw4w9WgXcQ`
- ✓ `http://www.youtube.com/watch?v=dQw4w9WgXcQ`
- ✓ `https://youtu.be/dQw4w9WgXcQ`
- ✓ `https://www.youtube.com/embed/dQw4w9WgXcQ`
- ✓ `https://www.youtube.com/v/dQw4w9WgXcQ`

### Valid URLs with Extra Parameters
- ✓ `https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=10s`
- ✓ `https://www.youtube.com/watch?v=dQw4w9WgXcQ&list=PLxxx&index=1`
- ✓ `https://www.youtube.com/watch?v=dQw4w9WgXcQ#t=10`

### Invalid Inputs
- ✗ Empty string
- ✗ Non-YouTube URLs (google.com, github.com, etc.)
- ✗ Malformed URLs (`not-a-url`, `youtube.com`, etc.)
- ✗ Invalid video IDs (`https://youtube.com/watch?v=invalid`)
- ✗ Whitespace-only strings
- ✗ URLs with special characters in video ID

### Edge Cases Handled
- Whitespace trimming
- Multiple URL parameters
- URL fragments
- Case variations
- Missing protocol
- Suspicious input (SQL injection-like strings)
- Very long URLs

## Benefits

1. **User Experience**
   - Instant feedback as users type
   - Clear error messages explaining what's wrong
   - Disabled submit button prevents submission of invalid URLs

2. **Reliability**
   - Server validates all input independently
   - No reliance on client-side validation alone
   - Specific error messages for debugging

3. **Security**
   - Input validation prevents malformed data
   - Strict type checking at both client and server
   - Protection against invalid URLs causing unexpected behavior

4. **Maintainability**
   - Centralized validation logic in `lib/youtube-validation.ts`
   - Reusable functions across the application
   - Clear separation of concerns

## Future Enhancements

1. **Testing Setup** - Add Jest/Vitest for unit tests
2. **Video ID Validation** - Add checks for valid video ID format before transcript fetch
3. **URL Preview** - Show extracted video ID to user for confirmation
4. **Analytics** - Track common validation failures to improve UX
5. **Rate Limiting** - Add request throttling to prevent abuse
