'use client'

import { useState, useEffect } from 'react'
import { getUrlValidationError, isValidYouTubeUrl } from '@/lib/youtube-validation'
import { recordTiming } from '@/lib/timing-history'
import { LoadingState } from './components/LoadingState'
import { SUPPORTED_LANGUAGES } from '@/lib/language-utils'
import { getUserId } from '@/lib/user-identity'
import { HistoryPanel } from './components/HistoryPanel'
import type { HistoryEntry } from '@/lib/history.types'

type SummaryLength = 'brief' | 'detailed' | 'comprehensive'

interface SummaryResponse {
  success: boolean
  videoId: string
  summary: string
  length: SummaryLength
  transcriptLanguage?: string
  transcriptLanguageCode?: string
  summaryLanguage?: string
}

interface ErrorResponse {
  error: string
}

export default function Home() {
  const [url, setUrl] = useState('')
  const [length, setLength] = useState<SummaryLength>('detailed')
  const [summary, setSummary] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [videoId, setVideoId] = useState('')
  const [urlError, setUrlError] = useState('')
  const [copiedFeedback, setCopiedFeedback] = useState<'success' | 'error' | null>(null)
  const [transcriptLanguage, setTranscriptLanguage] = useState('auto')
  const [summaryLanguage, setSummaryLanguage] = useState('English')
  const [detectedLanguage, setDetectedLanguage] = useState('')
  const [historyOpen, setHistoryOpen] = useState(false)

  // Load settings from localStorage on mount
  useEffect(() => {
    const savedLength = localStorage.getItem('summaryLength')
    const savedTranscriptLang = localStorage.getItem('transcriptLanguage')
    const savedSummaryLang = localStorage.getItem('summaryLanguage')

    if (savedLength && ['brief', 'detailed', 'comprehensive'].includes(savedLength)) {
      setLength(savedLength as SummaryLength)
    }
    if (savedTranscriptLang) {
      setTranscriptLanguage(savedTranscriptLang)
    }
    if (savedSummaryLang) {
      setSummaryLanguage(savedSummaryLang)
    }
  }, [])

  // Save settings to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('summaryLength', length)
  }, [length])

  useEffect(() => {
    localStorage.setItem('transcriptLanguage', transcriptLanguage)
  }, [transcriptLanguage])

  useEffect(() => {
    localStorage.setItem('summaryLanguage', summaryLanguage)
  }, [summaryLanguage])

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newUrl = e.target.value
    setUrl(newUrl)

    // Validate URL on change
    if (newUrl.trim()) {
      const validationError = getUrlValidationError(newUrl)
      setUrlError(validationError || '')
    } else {
      setUrlError('')
    }
  }

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(summary)
      setCopiedFeedback('success')
      // Clear feedback after 2 seconds
      setTimeout(() => {
        setCopiedFeedback(null)
      }, 2000)
    } catch {
      setCopiedFeedback('error')
      // Clear error feedback after 3 seconds
      setTimeout(() => {
        setCopiedFeedback(null)
      }, 3000)
    }
  }

  const saveToHistory = async (
    videoId: string,
    url: string,
    summary: string,
    length: SummaryLength,
    transcriptLanguage?: string,
    summaryLanguage?: string
  ) => {
    try {
      const userId = getUserId()
      await fetch('/api/history', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-user-id': userId,
        },
        body: JSON.stringify({
          videoId,
          url,
          summary,
          length,
          transcriptLanguage,
          summaryLanguage,
        }),
      })
    } catch (error) {
      console.error('Failed to save to history:', error)
    }
  }

  const handleSelectHistoryEntry = (entry: HistoryEntry) => {
    setUrl(entry.url)
    setLength(entry.length)
    setSummary(entry.summary)
    setVideoId(entry.videoId)
    setDetectedLanguage(entry.transcriptLanguage || '')
    setHistoryOpen(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSummary('')

    // Final client-side validation before submission
    const validationError = getUrlValidationError(url)
    if (validationError) {
      setError(validationError)
      return
    }

    if (!isValidYouTubeUrl(url)) {
      setError('Please enter a valid YouTube URL.')
      return
    }

    setLoading(true)
    const startTime = Date.now()

    try {
      const requestBody: {
        url: string
        length: SummaryLength
        transcriptLanguage?: string
        summaryLanguage: string
      } = {
        url,
        length,
        summaryLanguage,
      }

      // Only include transcriptLanguage if not 'auto'
      if (transcriptLanguage !== 'auto') {
        requestBody.transcriptLanguage = transcriptLanguage
      }

      const response = await fetch('/api/summarize', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      })

      const data = (await response.json()) as SummaryResponse | ErrorResponse
      const totalTime = Math.round((Date.now() - startTime) / 1000)

      if (!response.ok || 'error' in data) {
        setError('error' in data ? data.error : 'Failed to summarize video')
        return
      }

      if ('summary' in data) {
        setSummary(data.summary)
        setVideoId(data.videoId)
        setDetectedLanguage(data.transcriptLanguage || '')

        // Record timing for adaptive estimation
        // Estimate phase times as proportions of total (this is client-side estimate)
        const fetchTime = Math.round(totalTime * 0.15) // ~15% for fetch
        const processTime = Math.round(totalTime * 0.15) // ~15% for processing
        const generateTime = totalTime - fetchTime - processTime // Rest for generation

        recordTiming(length, Math.max(1, fetchTime), Math.max(1, processTime), Math.max(1, generateTime))

        // Save to history
        saveToHistory(data.videoId, url, data.summary, length, data.transcriptLanguage, summaryLanguage)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-4 mb-2">
            <h1 className="text-5xl font-bold text-gray-900">
              YouTube <span className="text-indigo-600">TLDW</span>
            </h1>
            <button
              onClick={() => setHistoryOpen(true)}
              className="px-4 py-2 bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 transition font-medium flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                />
              </svg>
              History
            </button>
          </div>
          <p className="text-xl text-gray-600">
            Get instant summaries of YouTube videos
          </p>
        </div>

        {/* Main Card */}
        <div className="bg-white rounded-lg shadow-xl p-8 mb-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* URL Input */}
            <div>
              <label htmlFor="url" className="block text-sm font-medium text-gray-700 mb-2">
                YouTube URL
              </label>
              <input
                type="url"
                id="url"
                value={url}
                onChange={handleUrlChange}
                placeholder="https://www.youtube.com/watch?v=..."
                className={`w-full px-4 py-3 border rounded-lg focus:ring-2 focus:border-transparent outline-none transition ${
                  urlError
                    ? 'border-red-300 focus:ring-red-500'
                    : 'border-gray-300 focus:ring-indigo-500'
                }`}
                required
              />
              {urlError && <p className="mt-2 text-sm text-red-600">{urlError}</p>}
            </div>

            {/* Length Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Summary Length
              </label>
              <div className="grid grid-cols-3 gap-4">
                {(['brief', 'detailed', 'comprehensive'] as const).map((option) => (
                  <label
                    key={option}
                    className={`flex items-center p-4 border-2 rounded-lg cursor-pointer transition ${
                      length === option
                        ? 'border-indigo-600 bg-indigo-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="length"
                      value={option}
                      checked={length === option}
                      onChange={(e) => setLength(e.target.value as SummaryLength)}
                      className="w-4 h-4 text-indigo-600"
                    />
                    <span className="ml-3 font-medium text-gray-700 capitalize">
                      {option}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            {/* Language Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Transcript Language */}
              <div>
                <label htmlFor="transcriptLanguage" className="block text-sm font-medium text-gray-700 mb-2">
                  Transcript Language
                </label>
                <select
                  id="transcriptLanguage"
                  value={transcriptLanguage}
                  onChange={(e) => setTranscriptLanguage(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                >
                  <option value="auto">Auto-detect</option>
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.name} ({lang.nativeName})
                    </option>
                  ))}
                </select>
                <p className="mt-1 text-xs text-gray-500">
                  Select video caption language or use auto-detect
                </p>
              </div>

              {/* Summary Language */}
              <div>
                <label htmlFor="summaryLanguage" className="block text-sm font-medium text-gray-700 mb-2">
                  Summary Language
                </label>
                <select
                  id="summaryLanguage"
                  value={summaryLanguage}
                  onChange={(e) => setSummaryLanguage(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition"
                >
                  {SUPPORTED_LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.name}>
                      {lang.name} ({lang.nativeName})
                    </option>
                  ))}
                </select>
                <p className="mt-1 text-xs text-gray-500">
                  Language for the generated summary
                </p>
              </div>
            </div>

            {/* Error Message */}
            {error && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-800 font-medium">Error</p>
                <p className="text-red-700">{error}</p>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={loading || !url || !!urlError}
              className={`w-full py-3 px-6 rounded-lg font-semibold text-white transition ${
                loading || !url || urlError
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-indigo-600 hover:bg-indigo-700 active:scale-95'
              }`}
            >
              {loading ? 'Summarizing...' : 'Generate Summary'}
            </button>
          </form>
        </div>

        {/* Loading State Overlay */}
        {loading && <LoadingState summaryLength={length} />}

        {/* History Panel */}
        <HistoryPanel
          isOpen={historyOpen}
          onClose={() => setHistoryOpen(false)}
          onSelectEntry={handleSelectHistoryEntry}
        />

        {/* Summary Display */}
        {summary && (
          <div className="bg-white rounded-lg shadow-xl p-8">
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-gray-900">Summary</h2>
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-sm font-medium capitalize">
                    {length}
                  </span>
                  {detectedLanguage && (
                    <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                      {detectedLanguage}
                    </span>
                  )}
                </div>
              </div>
              <p className="text-sm text-gray-500">Video ID: {videoId}</p>
            </div>

            <div className="prose prose-sm max-w-none bg-gray-50 p-6 rounded-lg">
              <div className="text-gray-800 whitespace-pre-wrap leading-relaxed">
                {summary}
              </div>
            </div>

            {/* Copy Button with Feedback */}
            <div className="mt-6 flex items-center gap-3">
              <button
                onClick={handleCopy}
                disabled={copiedFeedback === 'success'}
                className={`px-4 py-2 rounded-lg transition font-medium flex items-center gap-2 ${
                  copiedFeedback === 'success'
                    ? 'bg-green-600 text-white hover:bg-green-700'
                    : copiedFeedback === 'error'
                      ? 'bg-red-600 text-white hover:bg-red-700'
                      : 'bg-indigo-600 text-white hover:bg-indigo-700'
                }`}
              >
                {copiedFeedback === 'success' ? (
                  <>
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                        clipRule="evenodd"
                      />
                    </svg>
                    Copied!
                  </>
                ) : copiedFeedback === 'error' ? (
                  <>
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                      <path
                        fillRule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                    Failed
                  </>
                ) : (
                  <>
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z"
                      />
                    </svg>
                    Copy to Clipboard
                  </>
                )}
              </button>
              {copiedFeedback && (
                <span
                  className={`text-sm font-medium ${
                    copiedFeedback === 'success' ? 'text-green-600' : 'text-red-600'
                  }`}
                >
                  {copiedFeedback === 'success' ? 'Summary copied successfully!' : 'Failed to copy'}
                </span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
